﻿=== Imperial Sword Cursor Set ===

By: Lightcm (http://www.rw-designer.com/user/73160)

Download: http://www.rw-designer.com/cursor-set/imperial-sword-lightcm

Author's description:

A new cursor pack for you, today I finally share it with you!
Free for personal use.

====Imperial Sword Cursor Install====
http://www.mediafire.com/file/1ynld26dbei7j69/Imperial%20Sword%20Cursor%20Install.inf

Please report bugs in the comments.

Enjoy!

======Contact======
https://plus.google.com/+AlexaLightCm
https://lightcm.deviantart.com/
-> lightcm08@gmail.com

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.